﻿namespace Domain.Entity.Dto
{
    public class ResetControlDto
    {
        public string Mail { get; set; }
        public string AuthorizationCode { get; set; }
    }
}
