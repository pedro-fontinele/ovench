﻿using Domain.Entity.Dto;
using Domain.Entity.Model;

namespace Domain.Entity.ManualMapping
{
    public static class ResetControlMapper
    {
        public static ResetControlDto MapToDto(ResetControl resetControl)
        {
            return new ResetControlDto
            {
                Mail = resetControl.Mail,
                AuthorizationCode = resetControl.AuthorizationCode
            };
        }

        public static ResetControl MapToModel(ResetControlDto resetControlDto)
        {
            return new ResetControl
            {
                Mail = resetControlDto.Mail,
                AuthorizationCode = resetControlDto.AuthorizationCode
            };
        }
    }
}
