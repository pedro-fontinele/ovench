﻿namespace Domain.Entity.Model
{
    public class ResetControl
    {
        public string Mail { get; set; }
        public string AuthorizationCode { get; set; }
    }
}
