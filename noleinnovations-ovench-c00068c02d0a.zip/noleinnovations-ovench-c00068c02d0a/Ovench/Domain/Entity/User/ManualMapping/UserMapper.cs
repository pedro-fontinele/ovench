﻿using Domain.Entity.Dto;
using Domain.Entity.Model;

namespace Domain.Entity.ManualMapping
{
    public static class UserMapper
    {
        public static UserDto MapToDto(User user)
        {
            return new UserDto
            {
                Id = user.Id,
                Name = user.Name,
                IsActive = user.IsActive,
                Mail = user.Mail,
                Password = user.Password,
                LastModifiedDate = user.LastModifiedDate
            };
        }

        public static User MapToModel(UserDto userDto)
        {
            return new User
            {
                Id = userDto.Id,
                Name = userDto.Name,
                IsActive = userDto.IsActive,
                Mail = userDto.Mail,
                Password = userDto.Password,
                LastModifiedDate = userDto.LastModifiedDate
            };
        }
    }
}
