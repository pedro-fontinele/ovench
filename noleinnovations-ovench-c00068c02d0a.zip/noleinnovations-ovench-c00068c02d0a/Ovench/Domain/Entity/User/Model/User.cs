﻿namespace Domain.Entity.Model
{
    public class User
    {
        public uint Id { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
        public string Mail { get; set; }
        public string Password { get; set; }
        public string LastModifiedDate { get; set; }
    }
}
