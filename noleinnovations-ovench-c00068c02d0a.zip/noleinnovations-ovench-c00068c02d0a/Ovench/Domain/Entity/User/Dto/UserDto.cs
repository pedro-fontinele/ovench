﻿namespace Domain.Entity.Dto
{
    public class UserDto
    {
        public uint Id { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
        public string Mail { get; set; }
        public string Password { get; set; }
        public string LastModifiedDate { get; set; }
    }
}
