﻿using Domain.Entity.Dto;
using Domain.Entity.Model;

namespace Domain.Entity.AutoMapper
{
    public static class SettingsSmtpClientMapper
    {
        public static SettingsSmtpClientDto MapToDto(SettingsSmtpClient settingsSmtpClient)
        {
            return new SettingsSmtpClientDto
            {
                SmtpServer = settingsSmtpClient.SmtpServer,
                SmtpPort = settingsSmtpClient.SmtpPort,
                Mail = settingsSmtpClient.Mail,
                Password = settingsSmtpClient.Password
            };
        }

        public static SettingsSmtpClient MapToModel(SettingsSmtpClientDto settingsSmtpClientDto)
        {
            return new SettingsSmtpClient
            {
                SmtpServer = settingsSmtpClientDto.SmtpServer,
                SmtpPort = settingsSmtpClientDto.SmtpPort,
                Mail = settingsSmtpClientDto.Mail,
                Password = settingsSmtpClientDto.Password
            };
        }
    }
}
