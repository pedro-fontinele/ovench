﻿namespace Domain.Entity.Dto
{
    public class DetailsMailMessageDto
    {
        public string To { get; set; }
        public string Name { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public string Password { get; set; }
    }
}
