﻿using Microsoft.Extensions.DependencyInjection;

namespace Persistence.Repository
{
    public static class RepositoryConfiguration
    {
        public static void AddRepositoryConfiguration(this IServiceCollection servicea)
        {
            servicea.AddTransient<IUsersRepository, UsersRepository>();
        }
    }
}
