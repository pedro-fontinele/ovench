﻿using Domain.Entity.Model;
using System.Threading.Tasks;

namespace Persistence.Repository
{
    public class UserRepository : IUsersRepository
    {
        public Task<User> GetUserByMail(string mail)
        {
            throw new System.NotImplementedException();
        }

        public Task InsertUser(User user)
        {
            throw new System.NotImplementedException();
        }

        public Task UpdateUser(User user)
        {
            throw new System.NotImplementedException();
        }
    }
}
