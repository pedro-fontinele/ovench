﻿using Domain.Entity.Model;
using System.Threading.Tasks;

namespace Persistence.Repository
{
    public interface IUsersRepository
    {
        // Consult
        Task<User> GetUserByMail(string mail);

        // Action
        Task InsertUser(User user);
        Task UpdateUser(User user);
    }
}
